public class Main {
    public static void main(String[] args) 
{
        System.out.println("Hello, India!");
        int a = 5, b = 70;
        int sum = a + b;
        System.out.println("Sum: " + sum);
    }
}
